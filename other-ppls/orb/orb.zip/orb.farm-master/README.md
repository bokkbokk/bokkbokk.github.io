<meta charset="utf-8"/>

# life jar

a sealed ecosystem

![jar](https://static.boredpanda.com/blog/wp-content/uploads/2014/04/sealed-bottle-garden-david-latimer-1.jpg)

![1](https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/FoodWebSimple.jpg/721px-FoodWebSimple.jpg)
![1](https://upload.wikimedia.org/wikipedia/commons/thumb/c/cb/ConsumerWikiPDiag.svg/800px-ConsumerWikiPDiag.svg.png)
![1](https://upload.wikimedia.org/wikipedia/commons/3/3a/Ecological_Pyramid.svg)
![1](https://www.reef2reef.com/proxy.php?image=http%3A%2F%2Fi458.photobucket.com%2Falbums%2Fqq303%2Fclintos08%2Fcarbon_flux_zpsywdllt49.jpg&hash=40cce2c19f76c82a440eb825a6b95686)
![1](https://upload.wikimedia.org/wikipedia/commons/5/55/Microbial_Loop.jpg)

https://www.shadertoy.com/view/tdSXzD
