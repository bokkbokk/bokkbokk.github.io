release checklist:

- light shines when it hits something

- audit tchotchkeys
- audit intro text / copy

* limit plant growth
* sand colors?
* drag tchotchkes sprite cursor

<!-- * selected button style -->
<!-- * gif snapshot menu -->
<!-- - slower tchotchkes -->
<!-- - supress welcome -->

=====================================================

Sunlight

Nutrients:
Sugar
Oxygen
C02
Nitrogen

Substrates:
Dirt
Stone
Water

Plants:
kelp
grass
algae

fungus & bactera
decomposer

Animals:
crab
snail
Fishs
mites

plant
ui
sand
element images + description
color grade
night light?
non-circlular tank
punnet square recessive genes red shrimp

prizes/ tchotchkeys

- broken pottery
- quartz crystal
- shell clam
- archway
