This is a little bit janky but it works! 

Intended to be a recipe manager + other things until Kanjis able to add official support


if it doesnt find the steam path automatically you can set it manually
also sidenote your phosimp exe should be named KANJI_CODER.PHO_SIMP.EXE