This is a little bit janky but it works! 

Intended to be a recipe manager + other things until Kanjis able to add official support


if it doesnt find the steam path automatically you can set it manually
also sidenote your phosimp exe should be named KANJI_CODER.PHO_SIMP.EXE


if you update the script you can either just replace the recipes folder with your old one 
or you can use the config to set a recipe directory to use instead of the default one
give it a full path like C:\Users\Name\Documents\phosimp-recipes\ or whatever u want 